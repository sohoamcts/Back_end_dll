﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassObjects
{
    public class BookingDetails
    {

        public int customer_id { set; get; }
        public int booking_id { set; get; }
        public string flight_no { set; get; }
        public int no_of_passenger { set; get; }
        public DateTime date_of_journey { set; get; }
        public DateTime booking_date { set; get; }
        public double total_price { set; get; }



    }
}
