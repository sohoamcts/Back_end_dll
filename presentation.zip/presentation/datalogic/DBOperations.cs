﻿using ClassObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace datalogic
{
    public class DBOperations
    {
        static SqlConnection Con = new SqlConnection(DBConnection.getConnection());
        static SqlCommand cmd = null;
        public static List<FlightSchedule> FlightSearch(string spname, List<SqlParameter> L)
        {
            Con.Open();
            cmd = new SqlCommand(spname, Con);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter P in L)
            {
                cmd.Parameters.Add(P);
            }
            SqlDataReader R = cmd.ExecuteReader();
            List<FlightSchedule> L1 = new List<FlightSchedule>();
            FlightSchedule F = null;
            while (R.Read())
            {
                F = new FlightSchedule();
                F.FlightNo = R[0].ToString();
                F.AirlineName = R[1].ToString();
                F.Locationfrom = R[2].ToString();
                F.DateofJourney = DateTime.Parse(R[3].ToString());
                F.LocationTo = R[4].ToString();
                F.DepartureTime = DateTime.Parse(R[5].ToString());
                F.Cost = double.Parse(R[6].ToString());
                F.ScheduleID = R[7].ToString();
                L1.Add(F);
                
            }
            Con.Close();
            return L1;
            



        }
        public static string insert(string sp_customerdetails2,List<SqlParameter> V)
        {
            try
            {
                Con.Open();
                cmd = new SqlCommand("sp_customerdetails2", Con);
                cmd.CommandType = CommandType.StoredProcedure;
                Customerdetails cd = new Customerdetails();
                foreach (SqlParameter p in V)
                {
                    cmd.Parameters.Add(p);
                }
                cmd.ExecuteNonQuery();
            }
            catch (Exception E)
            {
                throw E;
            }
            finally
            {

                Con.Close();
            }
            return V[V.Count - 1].Value.ToString();

            }
        public static int getCustID()
        {
            int cid;
            Con.Open();
            cmd = new SqlCommand("sp_CustId",Con);
            cmd.CommandType = CommandType.StoredProcedure;
           SqlDataReader R= cmd.ExecuteReader();
           R.Read();
            cid=int.Parse(R[0].ToString()) + 1;
           Con.Close();
           return cid;
           
        }

        public static bool loginValidate(string spname, List<SqlParameter> L)
        {
            bool flag = false;
            try
            {
                Con.Open();
                cmd = new SqlCommand(spname, Con);
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter P in L)
                {
                    cmd.Parameters.Add(P);
                }
                SqlDataReader R = cmd.ExecuteReader();
                if (R.Read())
                {
                    flag = true;

                }
            }
            catch (Exception E)
            {
                throw E;
            }
            finally
            {
                Con.Close();
            }
            return flag;

        }
    }
}
