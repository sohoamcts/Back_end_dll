﻿using ClassObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace presentation
{
    public partial class Booking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            FlightSchedule F = (FlightSchedule)Cache["Flight"];

            TextBox1.Text = F.FlightNo;
        }
    }
}