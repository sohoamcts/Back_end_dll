﻿function validate() {
    flag = true;
    str = "";
    var cn = document.getElementById("name").value;
    var a = new RegExp("^[A-Za-z]{1,}$");
    if (cn.trim().length == 0) {
        flag = false;
        str = str + "\n" + "Customer name cannot be empty";
    }
    else if (!a.test(cn)) {
        flag = false;
        str = str + "\n" + "name should not contain special characters";
    }

    var r = new RegExp("^[A-Za-z]{1,}[A-Za-z0-9]{1,}@[A-Za-z]{2,}.(com|co.in|org|in)$");
    var e = document.getElementById("email").value;
    if (e == "") {
        flag = false;
        str += "\n" + "Email can not be empty";
    }
    else if (!r.test(e)) {
        str = str + "\n" + "Email is invalid";
        flag = false;

    }
    var r1 = new RegExp("^[A-Za-z0-9]{1,}(!@#$%^&*){1,}$");
    var e1 = document.getElementById("password").value;
    if (!r1.test(e) && e1.trim().length == 0) {
        flag = false;
        str = str + "\n" + "password is invalid";
    }

    var db = document.getElementById("dob").value;
    if (db == "") {
        flag = false;
        str = str + "\n" + "Dob can not be empty";
    }


    var ad = document.getElementById("address").value;
    if (ad == "") {
        flag = false;
        str = str + "\n" + "address can not be empty";
    }

    var ph = document.getElementById("phone").value;
    if (ph == "") {
        flag = false;
        str = str + "\n" + "phone number can not be empty";
    }

    var g = document.getElementById("gender").value;
    if (g == "select") {
        flag = false;
        str = str + "\n" + "Gender must be selected";
    }

    var st = document.getElementById("ssntype").value;
    if (st == "") {
        flag = false;
        str = str + "\n" + "ssn type can not be empty";
    }

    var g1 = document.getElementById("ssnnumber").value;
    if (g1 == "") {
        flag = false;
        str = str + "\n" + "ssn number can not be empty";
    }
    if (flag == false) {
        alert(str);
        return false;
    }
    else {
        return true;

    }
}